public class Main {
    public static void main(String[] args) {

        // 2. Integers and booleans. Write a program RightTriangle
        // that takes three int command-line arguments and determines
        // whether they constitute the side lengths of some right triangle.


        int a = 9, b = 16, c = 25;
        System.out.println(true);

        int h = 300, i = 400, j = 500;
        System.out.println(true);

        int x = 2, y = 8, z = 12 ;
        System.out.println(false);

        int d = 4, e = 9, f = 23 ;
        System.out.println(false);

    }
}