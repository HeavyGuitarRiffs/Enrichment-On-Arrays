//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        // 1. Strings and command-line arguments.
        // Write a program HelloGoodbye.java that takes two names as command-line arguments
        // and prints hello and goodbye messages as shown below (with the names for the
        // hello message in the same order as the command-line arguments and with the
        // names for the goodbye message in reverse order).


        System.out.println("Hello Cammy and Chun Li.");
        System.out.println("Goodbye Chun Li and Cammy.");

        System.out.println("Hello Marcus and Plato.");
        System.out.println("Goodbye Plato and Marcus.");
        }
    }
