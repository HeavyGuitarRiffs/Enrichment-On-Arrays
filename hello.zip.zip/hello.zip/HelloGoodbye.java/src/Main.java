//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        String myText1;
        myText1 = "Hello Cammy and Chun Li.";

        String myText2;
        myText2 = "Goodbye Chun Li and Cammy.";

        String myText3;
        myText3 = "Hello Marcus and Plato.";

        String myText4;
        myText4 = "Goodbye Plato and Marcus.";

        System.out.println(myText1);
        System.out.println(myText2);

        System.out.println(myText3);
        System.out.println(myText4);
        }
    }
