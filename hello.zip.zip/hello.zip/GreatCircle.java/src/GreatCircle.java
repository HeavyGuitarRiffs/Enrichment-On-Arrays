//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class GreatCircle {
    public static void main(String[] args) {

       

        System.out.println(Math.toRadians(43.6532));
        System.out.println(Math.toRadians(79.3832));
        System.out.println(Math.toRadians(20.2114));
        System.out.println(Math.toRadians(87.4654));
        // Toronto to Tulum

        System.out.println(Math.toRadians(64.9631));
        System.out.println(Math.toRadians(19.0208));
        System.out.println(Math.toRadians(30.5595));
        System.out.println(Math.toRadians(22.9375));
        //Iceland to South Africa

        }
    }
