public class Main {
    public static void main(String[] args) {




        int a = 9, b = 16, c = 25;
        boolean isTriangleOne = true;
        System.out.println(isTriangleOne);


        int h = 300, i = 400, j = 500;
        boolean isTriangleTwo = true;
        System.out.println(isTriangleTwo);

        int x = 2, y = 8, z = 12 ;
        boolean isTriangleThree = false;
        System.out.println(isTriangleThree);

        int t = 4, u = 9, v = 23 ;
        boolean isTriangleFour = false;
        System.out.println(isTriangleFour);

    }
}